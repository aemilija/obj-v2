var searchData=
[
  ['ndmediana_0',['ndMediana',['../_stud_8cpp.html#af7d2a6d5317b08a2cfc6a75e15113d05',1,'ndMediana(const Stud &amp;student):&#160;Stud.cpp'],['../_stud_8h.html#af7d2a6d5317b08a2cfc6a75e15113d05',1,'ndMediana(const Stud &amp;student):&#160;Stud.cpp']]],
  ['ndvidurkis_1',['ndVidurkis',['../_stud_8cpp.html#a6127fdd3f188afc7cc8f39955d1b2eca',1,'ndVidurkis(const Stud &amp;student):&#160;Stud.cpp'],['../_stud_8h.html#a6127fdd3f188afc7cc8f39955d1b2eca',1,'ndVidurkis(const Stud &amp;student):&#160;Stud.cpp']]],
  ['nuskaitytifaila_2',['nuskaitytiFaila',['../_stud_8cpp.html#a8ee83ccabf0dc0f11d8cef998b52e5c9',1,'nuskaitytiFaila(vector&lt; Stud &gt; &amp;student, string failoPav):&#160;Stud.cpp'],['../_stud_8h.html#a8ee83ccabf0dc0f11d8cef998b52e5c9',1,'nuskaitytiFaila(vector&lt; Stud &gt; &amp;student, string failoPav):&#160;Stud.cpp']]]
];
