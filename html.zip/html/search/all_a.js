var searchData=
[
  ['test_0',['test',['../_stud_8cpp.html#ae1a3968e7947464bee7714f6d43b7002',1,'test():&#160;Stud.cpp'],['../_stud_8h.html#ae1a3968e7947464bee7714f6d43b7002',1,'test():&#160;Stud.cpp']]]
];
