var searchData=
[
  ['atsitiktiniaipazymiai_0',['atsitiktiniaiPazymiai',['../_stud_8cpp.html#aa22aa552bd71fe8c4571ede9d36da2fa',1,'atsitiktiniaiPazymiai(vector&lt; Stud &gt; &amp;student, double ndSkaicius):&#160;Stud.cpp'],['../_stud_8h.html#aa22aa552bd71fe8c4571ede9d36da2fa',1,'atsitiktiniaiPazymiai(vector&lt; Stud &gt; &amp;student, double ndSkaicius):&#160;Stud.cpp']]]
];
