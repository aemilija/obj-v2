var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_stud.html#ae99a62e7e1e93e2c0907d7e85a37b6e2',1,'Stud']]],
  ['operator_3d_1',['operator=',['../class_stud.html#a5173b1e2a8ee8730559781ab2ae4a7cf',1,'Stud']]],
  ['operator_3e_3e_2',['operator&gt;&gt;',['../class_stud.html#a92f8262a0021e858c0cb8696c737d863',1,'Stud']]]
];
