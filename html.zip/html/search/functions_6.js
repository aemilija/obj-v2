var searchData=
[
  ['operator_3d_0',['operator=',['../class_stud.html#a5173b1e2a8ee8730559781ab2ae4a7cf',1,'Stud']]]
];
