var searchData=
[
  ['setegz_0',['setEgz',['../class_stud.html#ae2d2eb62ff9f00e725ee0852b38f1f38',1,'Stud']]],
  ['setnd_1',['setNd',['../class_stud.html#a12da3f4d17f23fd0e722a67a81ec93af',1,'Stud']]],
  ['setonepaz_2',['setOnePaz',['../class_stud.html#a6c257d74d75acc872e46c42d6f3414be',1,'Stud']]],
  ['setpavarde_3',['setPavarde',['../class_zmogus.html#aa53dcb62d00cab970b183cffa79899b4',1,'Zmogus::setPavarde()'],['../class_stud.html#aa7a2e5945cb215b6d222d852d4ac38c1',1,'Stud::setPavarde()']]],
  ['setvardas_4',['setVardas',['../class_zmogus.html#a8a291222f8631ea8ab7bd33fcb5f4198',1,'Zmogus::setVardas()'],['../class_stud.html#a721e8033934adf38fe3cf8dcd5ba327b',1,'Stud::setVardas()']]],
  ['spausdinti_5',['spausdinti',['../_stud_8cpp.html#a20f75b3c982f3d6f5cfba994143a7210',1,'spausdinti(vector&lt; Stud &gt; &amp;student, char pasirinkimas):&#160;Stud.cpp'],['../_stud_8h.html#a63eac58b4252940318337852b61439ac',1,'spausdinti(vector&lt; Stud &gt; &amp;studentai, char pasirinkimas):&#160;Stud.cpp']]],
  ['stud_6',['Stud',['../class_stud.html',1,'Stud'],['../class_stud.html#a97585839898d45dc9fc815d5b36e2b69',1,'Stud::Stud()'],['../class_stud.html#a4298d701557b0a4ca580f001c3b4e7a0',1,'Stud::Stud(const string &amp;v, const string &amp;p, const vector&lt; int &gt; n, int e)'],['../class_stud.html#aa4f6e2ef2908b642c308a1d066ab611a',1,'Stud::Stud(const Stud &amp;kitas)']]],
  ['stud_2ecpp_7',['Stud.cpp',['../_stud_8cpp.html',1,'']]],
  ['stud_2eh_8',['Stud.h',['../_stud_8h.html',1,'']]]
];
