var searchData=
[
  ['paskirtytistud_0',['paskirtytiStud',['../_stud_8cpp.html#a1170a0c36d67c8782a082eb10a1fafd8',1,'paskirtytiStud(std::vector&lt; Stud &gt; &amp;studentai, std::vector&lt; Stud &gt; &amp;saunuoliai, std::vector&lt; Stud &gt; &amp;nevykeliai, char pasirinkimas):&#160;Stud.cpp'],['../_stud_8h.html#a6794f18e51e36d5bd6d351c78bf31e71',1,'paskirtytiStud(vector&lt; Stud &gt; &amp;studentai, vector&lt; Stud &gt; &amp;saunuoliai, vector&lt; Stud &gt; &amp;nevykeliai, char pasirinkimas):&#160;Stud.h']]],
  ['patikrinti_1',['patikrinti',['../_stud_8cpp.html#a1cd8af29268f6d6690759657cb8d360c',1,'patikrinti(bool a, const string &amp;pav):&#160;Stud.cpp'],['../_stud_8h.html#a1cd8af29268f6d6690759657cb8d360c',1,'patikrinti(bool a, const string &amp;pav):&#160;Stud.cpp']]],
  ['pavarde_2',['pavarde',['../class_zmogus.html#a00799e1396c82e4f6dffa0edec1f24e5',1,'Zmogus']]]
];
