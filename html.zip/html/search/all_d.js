var searchData=
[
  ['_7estud_0',['~Stud',['../class_stud.html#aa1c38d670d1f269ebd48588c40ad58db',1,'Stud']]],
  ['_7ezmogus_1',['~Zmogus',['../class_zmogus.html#a64c712eed93f3dc770bb00df890292d7',1,'Zmogus']]]
];
