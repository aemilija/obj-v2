var searchData=
[
  ['isvestifaila_0',['isvestiFaila',['../_stud_8cpp.html#a5fb4ba563ad06a66bb3c0e8db630ce89',1,'isvestiFaila(vector&lt; Stud &gt; student, char pasirinkimas, string failoPav):&#160;Stud.cpp'],['../_stud_8h.html#a5fb4ba563ad06a66bb3c0e8db630ce89',1,'isvestiFaila(vector&lt; Stud &gt; student, char pasirinkimas, string failoPav):&#160;Stud.cpp']]],
  ['ivestiduomenisranka_1',['ivestiDuomenisRanka',['../_stud_8cpp.html#aaa6d4ff68549d02b4a8e9eb7cdad48e9',1,'ivestiDuomenisRanka(vector&lt; Stud &gt; &amp;student, int ndSkaicius):&#160;Stud.cpp'],['../_stud_8h.html#aaa6d4ff68549d02b4a8e9eb7cdad48e9',1,'ivestiDuomenisRanka(vector&lt; Stud &gt; &amp;student, int ndSkaicius):&#160;Stud.cpp']]]
];
