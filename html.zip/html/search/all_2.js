var searchData=
[
  ['galutinis_0',['galutinis',['../_stud_8cpp.html#ab68d1891e6b1983311481f8486fa7331',1,'galutinis(const Stud &amp;student, char pasirinkimas):&#160;Stud.cpp'],['../_stud_8h.html#ab68d1891e6b1983311481f8486fa7331',1,'galutinis(const Stud &amp;student, char pasirinkimas):&#160;Stud.cpp']]],
  ['generuotifailus_1',['generuotiFailus',['../_stud_8cpp.html#a8be31d6871f85e44c3b2428b98dde277',1,'generuotiFailus(string failoPav, int studSk):&#160;Stud.cpp'],['../_stud_8h.html#a8be31d6871f85e44c3b2428b98dde277',1,'generuotiFailus(string failoPav, int studSk):&#160;Stud.cpp']]],
  ['getegz_2',['getEgz',['../class_stud.html#a25998973a74b359a72a95d49beae0c08',1,'Stud']]],
  ['getnd_3',['getNd',['../class_stud.html#a647285e6b850a55cc0d61c12fb981e23',1,'Stud']]],
  ['getonepaz_4',['getOnePaz',['../class_stud.html#ad295841b0a24f855afb486f2aa4a8a64',1,'Stud']]],
  ['getpavarde_5',['getPavarde',['../class_zmogus.html#a11ee9ac120fbb7d6a4e1f4da3a602b63',1,'Zmogus::getPavarde()'],['../class_stud.html#a317787903c9f39f55c9da1fd80656962',1,'Stud::getPavarde()']]],
  ['getvardas_6',['getVardas',['../class_zmogus.html#aaea44664c236e2fadf022f3821862499',1,'Zmogus::getVardas()'],['../class_stud.html#aaa552b5446b9aed18832a897f3e03488',1,'Stud::getVardas()']]]
];
