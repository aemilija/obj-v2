var searchData=
[
  ['dablaikas_0',['dabLaikas',['../_stud_8cpp.html#aa6ac0f52bab37033dfbd9a6f9278fe38',1,'dabLaikas():&#160;Stud.cpp'],['../_stud_8h.html#aa6ac0f52bab37033dfbd9a6f9278fe38',1,'dabLaikas():&#160;Stud.cpp']]]
];
